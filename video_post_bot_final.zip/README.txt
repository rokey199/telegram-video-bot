Installation Steps for PythonAnywhere:

1. Upload this zip file to your PythonAnywhere Files tab.
2. Unzip the file.
3. Open a Bash console and navigate into the directory:
   cd video_post_bot_fixed_final
4. Create a virtual environment:
   python3.10 -m venv venv
5. Activate the environment:
   source venv/bin/activate
6. Install dependencies:
   pip install -r requirements.txt
7. Run the bot (only in a console, not as a web app):
   python bot.py

Make sure to replace `your_bot_token_here` in the `.env` file with your actual Telegram bot token.